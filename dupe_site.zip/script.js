const cart = [];

function addToCart(product) {
    cart.push(product);
    alert(product + ' adicionado ao carrinho!');
}
